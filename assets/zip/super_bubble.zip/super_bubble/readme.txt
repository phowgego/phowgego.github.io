Extract the files to a folder.
Install the Visual Studio redistributable if required (vc_redist.x86.exe).
Run bin/super_bubble.exe